﻿namespace CarManufacturer;

public class StartUp
{
    static void Main()
    {
        Car car = new Car()
        {
            Make = "VW",
            Model = "Pasat",
            Year = 2006
            
        };

        Console.WriteLine($"Make: {car.Make}\nModel: {car.Model}\nYear: {car.Year}");
    }
}
