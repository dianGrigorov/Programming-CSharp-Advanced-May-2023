﻿using GenericArrayCreator;

string[] strings = ArrayCreator.Create(5, "Pesho");
int[] integers = ArrayCreator.Create(5, 2);