﻿using GenericScale;

EqualityScale<int> scale = new(5, 56);

Console.WriteLine(scale.AreEqual());